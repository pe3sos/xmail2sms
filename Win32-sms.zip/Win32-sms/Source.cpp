
#include <windows.h>
#include <richedit.h>
#include <winhttp.h>
#pragma comment(lib,  "winhttp")
#define eW(x) MessageBoxW(hWnd, (LPCWSTR)L"", (LPCWSTR)x, 0);
HINSTANCE hInst; HWND hWnd, nr, txt, sendsms;
char g_nr[12], g_txt[160], g_str[260];
HFONT dF = CreateFontW(15,0,0,0,0,0,0,0,1,0,0,0,0, L"courier new");



void Ajax(char *ptxt)
{
   HINTERNET hi = 0, hc = 0, hr = 0;/* DWORD dw; char resp[2] = "";*/
   hi = WinHttpOpen(L"sms client/1.0", WINHTTP_ACCESS_TYPE_NO_PROXY, 0, 0, 0);
   if(hi) hc = WinHttpConnect(hi, L"10.10.0.8", 80, 0); else eW(L"! WinHttpOpen");
   if(hc) hr = WinHttpOpenRequest(hc, L"POST", L"dd/trimite.php", 0,0,0,0); else eW(L"! WinHttpConnect");

   if(hr)
   {
      WinHttpAddRequestHeaders(hr, L"content-type: application/x-www-form-urlencoded", -1L, WINHTTP_ADDREQ_FLAG_ADD);
      WinHttpSendRequest(hr, 0, 0, ptxt, strlen(ptxt), strlen(ptxt), 0);
      if(!WinHttpReceiveResponse(hr,0)) { MessageBoxA(0,"err","err",0); goto final; } //else WinHttpReadData(hr, resp, 2, &dww);
      else DestroyWindow(hWnd);

      //switch(resp[0])
      //{

      //case '1': MessageBoxA(0,"1","1",0); break;

      //case '0': MessageBoxA(0,"0","0",0); break; //aveti ultima versiune

      //default: MessageBoxA(0,"eroare ajax","eroare ajax",0); //eroare ajax

      //}
   }
   else eW(L"! WinHttpOpenRequest");

   final:
   WinHttpCloseHandle(hr); WinHttpCloseHandle(hc); WinHttpCloseHandle(hi);
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT m, WPARAM wParam, LPARAM lParam)
{
   switch (m)
   {

   case WM_COMMAND: 

      switch(LOWORD(wParam))
      {

      case 13:
         GetWindowTextA(nr, g_nr, 12); GetWindowTextA(txt, g_txt, 160);
         wsprintfA(g_str, "trimite=Trimite mesajul&telefon=%s&message=%s", g_nr, g_txt);
         Ajax(g_str);
         break;

      }

      break;

   case WM_DESTROY: PostQuitMessage(0); break;
   default: return DefWindowProcW(hWnd, m, wParam, lParam);
   }

   return 0L;
}




int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow)
{
   WNDCLASSEX wcex; wcex.cbSize = sizeof(WNDCLASSEX);
   wcex.style          = CS_HREDRAW | CS_VREDRAW;
   wcex.lpfnWndProc    = WndProc; wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
   wcex.hInstance      = hInstance;
   wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
   wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
   wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW);
   wcex.lpszMenuName   = NULL; wcex.lpszClassName  = L"cls";
   wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
   RegisterClassEx(&wcex);

   hInst = hInstance;

   hWnd = CreateWindowExW(0, L"cls", L"sms client", WS_SYSMENU, 333, 222, 470, 260, 0, 0, hInstance, 0);

   nr = CreateWindowExW(0, L"edit", L"40744520056", WS_CHILD|WS_VISIBLE|WS_BORDER, 10, 10, 222, 22, hWnd, (HMENU)11, hInst, 0);
   SendMessageW(nr, WM_SETFONT, (WPARAM)dF, MAKELPARAM(1,0));

   txt = CreateWindowExW(0, L"edit", L"textul", WS_CHILD|WS_VISIBLE|ES_MULTILINE|WS_BORDER|WS_VSCROLL, 10, 40, 444, 150, hWnd, (HMENU)12, hInst, 0);
   SendMessageW(txt, WM_SETFONT, (WPARAM)dF, MAKELPARAM(1,0));
   SendMessageW(txt, EM_LIMITTEXT, 1024, 0);

   sendsms = CreateWindowExW(0, L"button", L"trimite", WS_CHILD|WS_VISIBLE|WS_BORDER, 10, 200, 100, 25, hWnd, (HMENU)13, hInst, 0);
   SendMessageW(sendsms, WM_SETFONT, (WPARAM)dF, MAKELPARAM(1,0));

   ShowWindow(hWnd, nCmdShow); UpdateWindow(hWnd);


   MSG msg; while (GetMessage(&msg, 0, 0, 0))  {  TranslateMessage(&msg); DispatchMessage(&msg); }

   return (int)msg.wParam;
}

